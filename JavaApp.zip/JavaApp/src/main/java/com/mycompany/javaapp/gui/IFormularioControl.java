/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.javaapp.gui;

/**
 *
 * @author Agos
 */
public interface IFormularioControl {

    void refrescarGrilla();

    void showAbm(int accion);
    
}
